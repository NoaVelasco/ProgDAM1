/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mundialinterfaz;

import java.io.Serializable;

/**
 *
 * @author dam1
 */
/**
 *
 * @author dam1
 */
public class Jugadores extends Selecciones implements Serializable {
    public final static long serialID = 32132133;
    String nombre;
    String apellido;
    int edad;
    int rendimiento;

    public Jugadores() {
    }

    public Jugadores(String nombre, String apellido, int edad, int rendimiento, String equipo) {
        super(equipo);
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.rendimiento = rendimiento;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getRendimiento() {
        return rendimiento;
    }

    public void setRendimiento(int rendimiento) {
        this.rendimiento = rendimiento;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    
    @Override
    public String toString() {
        return "Jugadores{" + "nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad + ", rendimiento=" + rendimiento + ", equipo="+ super.getEquipo()+'}';
    }
    
    
    
}