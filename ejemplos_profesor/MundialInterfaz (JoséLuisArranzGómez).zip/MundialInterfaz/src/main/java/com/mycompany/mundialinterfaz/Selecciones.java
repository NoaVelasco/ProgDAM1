/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mundialinterfaz;

/**
 *
 * @author dam1
 */
public class Selecciones {
    String equipo;

    public Selecciones() {
    }

    public Selecciones(String equipo) {
        this.equipo = equipo;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    @Override
    public String toString() {
        return "Selecciones{" + "equipo=" + equipo + '}';
    }
    
    
}
