/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mundialinterfaz;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author dam1
 */
public class MundialInterfaz {
    
    static ArrayList<Selecciones> selecciones = new ArrayList<Selecciones>();
    
    static ArrayList<Jugadores> jugadores1 = new ArrayList<Jugadores>();
    static ArrayList<Jugadores> jugadores2 = new ArrayList<Jugadores>();
    static ArrayList<Jugadores> jugadores3 = new ArrayList<Jugadores>();
    static ArrayList<Jugadores> jugadores4 = new ArrayList<Jugadores>();
    
    static ArrayList<Jugadores> jugadoresM1 = new ArrayList<Jugadores>();
    static ArrayList<Jugadores> jugadoresM2 = new ArrayList<Jugadores>();
    static ArrayList<Jugadores> jugadoresM3 = new ArrayList<Jugadores>();
    static ArrayList<Jugadores> jugadoresM4 = new ArrayList<Jugadores>();
    
    public static void EscribirJugadores1(Jugadores j1, Jugadores j2, Jugadores j3, Jugadores j4, Jugadores j5, Jugadores j6, Jugadores j7, Jugadores j8,Jugadores j9, Jugadores j10){
        try {
            FileOutputStream fos = new FileOutputStream("jugadores1.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(j1);
            oos.writeObject(j2);
            oos.writeObject(j3);
            oos.writeObject(j4);
            oos.writeObject(j5);
            oos.writeObject(j6);
            oos.writeObject(j7);
            oos.writeObject(j8);
            oos.writeObject(j9);
            oos.writeObject(j10);
            oos.flush();
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el fichero");
        } catch (IOException ex) {
            System.out.println("No se puede leer el fichero");
        }
    }
    
    public static void EscribirJugadores2(Jugadores j1, Jugadores j2, Jugadores j3, Jugadores j4, Jugadores j5, Jugadores j6, Jugadores j7, Jugadores j8,Jugadores j9, Jugadores j10){
        try {
            FileOutputStream fos = new FileOutputStream("jugadores2.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(j1);
            oos.writeObject(j2);
            oos.writeObject(j3);
            oos.writeObject(j4);
            oos.writeObject(j5);
            oos.writeObject(j6);
            oos.writeObject(j7);
            oos.writeObject(j8);
            oos.writeObject(j9);
            oos.writeObject(j10);
            oos.flush();
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el fichero");
        } catch (IOException ex) {
            System.out.println("No se puede leer el fichero");
        }
    }
    
    public static void EscribirJugadores3(Jugadores j1, Jugadores j2, Jugadores j3, Jugadores j4, Jugadores j5, Jugadores j6, Jugadores j7, Jugadores j8,Jugadores j9, Jugadores j10){
        try {
            FileOutputStream fos = new FileOutputStream("jugadores3.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(j1);
            oos.writeObject(j2);
            oos.writeObject(j3);
            oos.writeObject(j4);
            oos.writeObject(j5);
            oos.writeObject(j6);
            oos.writeObject(j7);
            oos.writeObject(j8);
            oos.writeObject(j9);
            oos.writeObject(j10);
            oos.flush();
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el fichero");
        } catch (IOException ex) {
            System.out.println("No se puede leer el fichero");
        }
    }
    
    public static void EscribirJugadores4(Jugadores j1, Jugadores j2, Jugadores j3, Jugadores j4, Jugadores j5, Jugadores j6, Jugadores j7, Jugadores j8,Jugadores j9, Jugadores j10){
        try {
            FileOutputStream fos = new FileOutputStream("jugadores4.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(j1);
            oos.writeObject(j2);
            oos.writeObject(j3);
            oos.writeObject(j4);
            oos.writeObject(j5);
            oos.writeObject(j6);
            oos.writeObject(j7);
            oos.writeObject(j8);
            oos.writeObject(j9);
            oos.writeObject(j10);
            oos.flush();
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el fichero");
        } catch (IOException ex) {
            System.out.println("No se puede leer el fichero");
        }
    }
    
    public static void EscribirSelecciones(Selecciones s1,Selecciones s2,Selecciones s3,Selecciones s4){
        try {
            FileOutputStream fos = new FileOutputStream("selecciones.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(s1);
            oos.writeObject(s2);
            oos.writeObject(s3);
            oos.writeObject(s4);
            oos.flush();
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el fichero de selecicones");
        } catch (IOException ex) {
            System.out.println("No se puede leer el fichero de selecicones");
        }
    }
    
    public static void RellenarJugadores1(){
        try {
            FileInputStream fis = new FileInputStream("jugadores1.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            Jugadores j = (Jugadores) ois.readObject();
            while(j != null){
                //System.out.println(j);
                jugadores1.add(j);
                j = (Jugadores) ois.readObject();
            }
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el fichero");
        } catch (IOException ex) {
            System.out.println("No se puede leer el fichero");
        } catch (ClassNotFoundException ex) {
            System.out.println("No coincide la clase");
        }  
    }
    
    public static void RellenarJugadores2(){
        try {
            FileInputStream fis = new FileInputStream("jugadores2.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            Jugadores j = (Jugadores) ois.readObject();
            while(j != null){
                //System.out.println(j);
                jugadores2.add(j);
                j = (Jugadores) ois.readObject();
            }
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el fichero");
        } catch (IOException ex) {
            System.out.println("No se puede leer el fichero");
        } catch (ClassNotFoundException ex) {
            System.out.println("No coincide la clase");
        }  
    }
    
    public static void RellenarJugadores3(){
        try {
            FileInputStream fis = new FileInputStream("jugadores3.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            Jugadores j = (Jugadores) ois.readObject();
            while(j != null){
                //System.out.println(j);
                jugadores3.add(j);
                j = (Jugadores) ois.readObject();
            }
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el fichero");
        } catch (IOException ex) {
            System.out.println("No se puede leer el fichero");
        } catch (ClassNotFoundException ex) {
            System.out.println("No coincide la clase");
        }  
    }
    
    public static void RellenarJugadores4(){
        try {
            FileInputStream fis = new FileInputStream("jugadores4.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            Jugadores j = (Jugadores) ois.readObject();
            while(j != null){
                //System.out.println(j);
                jugadores4.add(j);
                j = (Jugadores) ois.readObject();
            }
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el fichero");
        } catch (IOException ex) {
            System.out.println("No se puede leer el fichero");
        } catch (ClassNotFoundException ex) {
            System.out.println("No coincide la clase");
        }  
    }
    
    public static void RellenarSelecciones(){
        try {
            FileInputStream fis = new FileInputStream("selecciones.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            Selecciones s = (Selecciones) ois.readObject();
            while(s != null){
                 selecciones.add(s);
                 s = (Jugadores) ois.readObject();
            }
        } catch (FileNotFoundException ex) {
            System.out.println("No existe el fichero de selecicones");
        } catch (IOException ex) {
            System.out.println("No se puede leer el fichero de selecicones");
        } catch (ClassNotFoundException ex) {
            System.out.println("No coincide la clase");
        }
    }
    
    public static void OrdenarJugadores1(ArrayList<Jugadores> jug){
        Jugadores aux;
        for(int i = 0;i < jug.size()-1;i++){
            for(int j = 0;j < jug.size()-i-1;j++){
                // El if de abajo va a determinar si el primero es menor que el segundo
                // y si es true, se va a realizar el swap con una variable aux para
                // mover los objetos del array
                if(jug.get(j+1).getRendimiento() > jug.get(j).getRendimiento()){    
                    aux = jug.get(j+1);
                    jug.set(j+1,jug.get(j));
                    jug.set(j,aux);
                }
            }
        }
        int contador=0;
        for (int i = 0; i<7; i++) {
            jugadoresM1.add(jug.get(i));
            if (contador<7){
                contador++;
                //System.out.println(jugadoresM1.get(i));
            } else {
                break;
            }
        }
    }
    
    public static void OrdenarJugadores2(ArrayList<Jugadores> jug){
        Jugadores aux;
        for(int i = 0;i < jug.size()-1;i++){
            for(int j = 0;j < jug.size()-i-1;j++){
                if(jug.get(j+1).getRendimiento() > jug.get(j).getRendimiento()){    
                    aux = jug.get(j+1);
                    jug.set(j+1,jug.get(j));
                    jug.set(j,aux);
                }
            }
        }
        int contador=0;
        for (int i = 0; i<7; i++) {
            jugadoresM2.add(jug.get(i));
            if (contador<7){
                contador++;
                //System.out.println(jugadoresM2.get(i));
            } else {
                break;
            }
        }
    }
    
    public static void OrdenarJugadores3(ArrayList<Jugadores> jug){
        Jugadores aux;
        for(int i = 0;i < jug.size()-1;i++){
            for(int j = 0;j < jug.size()-i-1;j++){
                if(jug.get(j+1).getRendimiento() > jug.get(j).getRendimiento()){    
                    aux = jug.get(j+1);
                    jug.set(j+1,jug.get(j));
                    jug.set(j,aux);
                }
            }
        }
        int contador=0;
        for (int i = 0; i<7; i++) {
            jugadoresM3.add(jug.get(i));
            if (contador<7){
                contador++;
                //System.out.println(jugadoresM3.get(i));
            } else {
                break;
            }
        }
    }
    
    public static void OrdenarJugadores4(ArrayList<Jugadores> jug){
        Jugadores aux;
        for(int i = 0;i < jug.size()-1;i++){
            for(int j = 0;j < jug.size()-i-1;j++){
                if(jug.get(j+1).getRendimiento() > jug.get(j).getRendimiento()){    
                    aux = jug.get(j+1);
                    jug.set(j+1,jug.get(j));
                    jug.set(j,aux);
                }
            }
        }
        int contador=0;
        for (int i = 0; i<7; i++) {
            jugadoresM4.add(jug.get(i));
            if (contador<7){
                contador++;
                //System.out.println(jugadoresM4.get(i));
            } else {
                break;
            }
        }
    }

    public static void main(String[] args) {
        Selecciones sel1 = new Selecciones("Filipinas");
        Selecciones sel2 = new Selecciones("Serbia");
        Selecciones sel3 = new Selecciones("Canada");
        Selecciones sel4 = new Selecciones("China");
        Jugadores jug11 = new Jugadores("Felipe","Bonito",40,54,"Filipinas");
        Jugadores jug12 = new Jugadores("Juan","Bonito",21,59,"Filipinas");
        Jugadores jug13 = new Jugadores("Pepe","Bonito",32,21,"Filipinas");
        Jugadores jug14 = new Jugadores("Lucas","Bonito",19,42,"Filipinas");
        Jugadores jug15 = new Jugadores("Felipe","Bonito",40,53,"Filipinas");
        Jugadores jug16 = new Jugadores("Pablo","Bonito",33,42,"Filipinas");
        Jugadores jug17 = new Jugadores("John","Bonito",24,61,"Filipinas");
        Jugadores jug18 = new Jugadores("Alberto","Bonito",48,52,"Filipinas");
        Jugadores jug19 = new Jugadores("Robert","Bonito",23,57,"Filipinas");
        Jugadores jug110 = new Jugadores("Daniel","Bonito",40,38,"Filipinas");
        
        Jugadores jug21 = new Jugadores("Slevig","Lupenki",52,67,"Serbia");
        Jugadores jug22 = new Jugadores("Dimitri","Lupenki",41,29,"Serbia");
        Jugadores jug23 = new Jugadores("Markov","Lupenki",38,43,"Serbia");
        Jugadores jug24 = new Jugadores("Viktor","Lupenki",27,55,"Serbia");
        Jugadores jug25 = new Jugadores("Yuri","Lupenki",52,21,"Serbia");
        Jugadores jug26 = new Jugadores("Donayev","Lupenki",45,36,"Serbia");
        Jugadores jug27 = new Jugadores("Lukayerisk","Lupenki",37,41,"Serbia");
        Jugadores jug28 = new Jugadores("Sergei","Lupenki",25,42,"Serbia");
        Jugadores jug29 = new Jugadores("Olimer","Lupenki",29,47,"Serbia");
        Jugadores jug210 = new Jugadores("Ionut","Lupenki",43,49,"Serbia");
        
        Jugadores jug31 = new Jugadores("Andrew","Johnson",27,24,"Canada");
        Jugadores jug32 = new Jugadores("Albert","Johnson",25,42,"Canada");
        Jugadores jug33 = new Jugadores("Dan","Johnson",45,51,"Canada");
        Jugadores jug34 = new Jugadores("Ben","Johnson",52,35,"Canada");
        Jugadores jug35 = new Jugadores("Pierre","Johnson",19,33,"Canada");
        Jugadores jug36 = new Jugadores("Peter","Johnson",32,45,"Canada");
        Jugadores jug37 = new Jugadores("John","Johnson",41,37,"Canada");
        Jugadores jug38 = new Jugadores("Eric","Johnson",28,29,"Canada");
        Jugadores jug39 = new Jugadores("George","Johnson",31,26,"Canada");
        Jugadores jug310 = new Jugadores("Xavier","Johnson",20,41,"Canada");
        
        Jugadores jug41 = new Jugadores("Lu","We",31,53,"China");
        Jugadores jug42 = new Jugadores("Xio","We",43,12,"China");
        Jugadores jug43 = new Jugadores("Li","We",25,41,"China");
        Jugadores jug44 = new Jugadores("Mong","We",34,26,"China");
        Jugadores jug45 = new Jugadores("Chin","We",23,50,"China");
        Jugadores jug46 = new Jugadores("Yu","We",41,25,"China");
        Jugadores jug47 = new Jugadores("Ghiu","We",35,27,"China");
        Jugadores jug48 = new Jugadores("Pio Fang","We",22,23,"China");
        Jugadores jug49 = new Jugadores("Bu","We",37,33,"China");
        Jugadores jug410 = new Jugadores("Riong","We",21,15,"China");
        
        EscribirSelecciones(sel1,sel2,sel3,sel4);
        EscribirJugadores1(jug11,jug12,jug13,jug14,jug15,jug16,jug17,jug18,jug19,jug110);
        EscribirJugadores2(jug21,jug22,jug23,jug24,jug25,jug26,jug27,jug28,jug29,jug210);
        EscribirJugadores3(jug31,jug32,jug33,jug34,jug35,jug36,jug37,jug38,jug39,jug310);
        EscribirJugadores4(jug41,jug42,jug43,jug44,jug45,jug46,jug47,jug48,jug49,jug410);
        
        RellenarJugadores1();
        RellenarJugadores2();
        RellenarJugadores3();
        RellenarJugadores4();
        
        OrdenarJugadores1(jugadores1);
        OrdenarJugadores2(jugadores2);
        OrdenarJugadores3(jugadores3);
        OrdenarJugadores4(jugadores4);
        
        GUIInterfaz interfaz = new GUIInterfaz(selecciones,jugadoresM1,jugadoresM2,jugadoresM3,jugadoresM4);
        interfaz.setBounds(450,300,1000,500);
        interfaz.setVisible(true);
        interfaz.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
    }
}
